<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class EnteringData extends Seeder
{
    public function run()
    {
        
    $data1 = [
        [
            'Fname' => 'Muhammad ' ,'Minit'=>'Faizan', 'Lname' => 'Azam', 
        'Address'=>'lahore','Bdate' => '2002-8-14',
        'Salary'=>20000,
        'Sex'=>'male',
        'Startdate'=>'2021-05-18',
        'Dep_ID'=>1,
        'Project_ID'=>1,
        'role'=>'supervisee'

        ]
    ];
    $data2 = [
        [
        'name'=>'IT ',
        'Number'=>1,
        'Location_ID'=>1

        ]
    ];
    $data3 = [
        [
            'Location'=>'Lahore'

        ]
    ];
    $data4= [
        [
            
            'name'=>'PUBG GAME',
            'Number'=>1,
            'Hours'=>48,
            'locations'=>'Lahore',
            'DEP_ID'=>1,
             

        ]
    ];
    $data5= [
        [
              'EMP_ID'=>1,
            'Name'=>'Asad',
            'sex'=>'Male',
            'Birth_date'=>'1990-05-15',
            'relationship'=>'cousin'


        ]
    ];
    \DB::table('location')->insert($data3); 
    \DB::table('department')->insert($data2);
    \DB::table('project')->insert($data4); 

    \DB::table('employee')->insert($data1); 
    
    \DB::table('dependent')->insert($data5); 


 


   }
}

