<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('employee', function (Blueprint $table) {
            $table->id();
            $table->string('Fname');
            $table->string('Minit');
            $table->string('Lname');
           
            $table->string('Address');
            $table->date('Bdate');
            $table->float('Salary')->default(0)->raw('CHECK(salary>0)');
            $table->enum('Sex',['male','female']);
            
            $table->date('StartDate');
            $table->unsignedBigInteger('Dep_ID')->nullable();

            $table->foreign('Dep_ID')
            ->references('id')->on('department')->onDelete('cascade');
            $table->unsignedBigInteger('Project_ID')->nullable();

            $table->foreign('Project_ID')
            ->references('id')->on('project')->onDelete('cascade')->onUpdate('set null');



            $table->enum('role',['Supervisor','supervisee']);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('employee');
    }
};
